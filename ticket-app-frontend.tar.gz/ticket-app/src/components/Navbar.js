import { NavLink } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="container navbar-inner">
        <NavLink to="/" className="navbar-brand">
          🎟 Ticket<span>Hub</span>
        </NavLink>
        <div className="navbar-links">
          <NavLink to="/" end className={({ isActive }) => isActive ? 'active' : ''}>
            Eventos
          </NavLink>
          <NavLink to="/admin" className={({ isActive }) => isActive ? 'active' : ''}>
            Admin
            <span className="navbar-badge">Panel</span>
          </NavLink>
        </div>
      </div>
    </nav>
  );
}
