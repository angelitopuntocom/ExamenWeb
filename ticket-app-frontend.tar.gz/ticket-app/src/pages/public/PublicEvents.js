import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getEvents } from '../../api/client';

function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' });
}

function formatTime(dt) {
  if (!dt) return '';
  return new Date(dt).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
}

export default function PublicEvents() {
  const [events, setEvents]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState('');
  const [search, setSearch]     = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    getEvents()
      .then(({ data }) => {
        const list = Array.isArray(data) ? data : data.data ?? [];
        setEvents(list.filter(e => e.status === 'Active'));
      })
      .catch(() => setError('No se pudo conectar con el servidor. Intenta de nuevo más tarde.'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = events.filter(ev =>
    ev.name?.toLowerCase().includes(search.toLowerCase()) ||
    ev.place?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      {/* Hero */}
      <section className="hero">
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <h1 className="hero-title">Vive la <em>experiencia</em></h1>
          <p className="hero-sub">Conciertos, conferencias y espectáculos. Elige tu evento y compra tus boletos.</p>
          <div style={{ maxWidth: 420, margin: '0 auto' }}>
            <input
              className="form-control"
              placeholder="🔍  Buscar por nombre o lugar…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{ fontSize: '1rem', padding: '.75rem 1rem' }}
            />
          </div>
        </div>
      </section>

      {/* Events */}
      <div className="page">
        <div className="container">
          {error && <div className="alert alert-error">⚠️ {error}</div>}

          {loading ? (
            <div className="spinner-page"><div className="spinner"/></div>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">🎭</div>
              <div className="empty-title">{search ? 'Sin resultados para tu búsqueda' : 'No hay eventos disponibles'}</div>
              <p>{search ? 'Intenta con otro término.' : 'Vuelve pronto, pronto habrá nuevos eventos.'}</p>
            </div>
          ) : (
            <>
              <div className="section-header">
                <div>
                  <h2 className="section-title">Próximos <span>Eventos</span></h2>
                  <p className="section-sub">{filtered.length} evento{filtered.length !== 1 ? 's' : ''} disponible{filtered.length !== 1 ? 's' : ''}</p>
                </div>
              </div>
              <div className="events-grid">
                {filtered.map(ev => (
                  <div key={ev.id} className="card card-hover" onClick={() => navigate(`/events/${ev.id}`)}>
                    <div className="event-card-date">
                      📅 {formatDate(ev.date)} · {formatTime(ev.date)}
                    </div>
                    <div className="event-card-name">{ev.name}</div>
                    <div className="event-card-place">📍 {ev.place}</div>
                    {ev.description && (
                      <div className="event-card-desc">{ev.description.substring(0, 100)}{ev.description.length > 100 ? '…' : ''}</div>
                    )}
                    {ev.zones?.length > 0 && (
                      <div className="zones-row">
                        {ev.zones.map(z => (
                          <div key={z.id} className="zone-chip">
                            {z.zoneType} · ${Number(z.price).toLocaleString('es-MX')}
                          </div>
                        ))}
                      </div>
                    )}
                    <button className="btn btn-primary btn-sm" style={{ marginTop: 'auto' }}>Ver Boletos →</button>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
