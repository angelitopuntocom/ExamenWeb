import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getEventById, getZonesByEvent, purchaseTickets } from '../../api/client';
import Modal from '../../components/Modal';

function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('es-MX', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

const ZONE_ICONS = { VIP: '👑', Preferente: '⭐', General: '🎫' };

export default function EventDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [event, setEvent]             = useState(null);
  const [zones, setZones]             = useState([]);
  const [loading, setLoading]         = useState(true);
  const [error, setError]             = useState('');

  // Purchase state
  const [selectedZone, setSelectedZone]   = useState(null);
  const [quantity, setQuantity]           = useState(1);
  const [buyerName, setBuyerName]         = useState('');
  const [buyerEmail, setBuyerEmail]       = useState('');
  const [showConfirm, setShowConfirm]     = useState(false);
  const [purchasing, setPurchasing]       = useState(false);
  const [purchaseResult, setPurchaseResult] = useState(null);

  useEffect(() => {
    Promise.all([getEventById(id), getZonesByEvent(id)])
      .then(([evRes, zoneRes]) => {
        const evData = evRes.data?.data ?? evRes.data;
        setEvent(evData);
        const zList = Array.isArray(zoneRes.data) ? zoneRes.data : zoneRes.data?.data ?? [];
        setZones(zList);
        if (zList.length > 0) setSelectedZone(zList[0]);
      })
      .catch(() => setError('No se pudo cargar el evento.'))
      .finally(() => setLoading(false));
  }, [id]);

  const total = selectedZone ? Number(selectedZone.price) * quantity : 0;

  async function handlePurchase() {
    setPurchasing(true);
    try {
      const { data } = await purchaseTickets({
        eventId:    parseInt(id),
        zoneId:     selectedZone.id,
        quantity,
        buyerName,
        buyerEmail,
        totalPrice: total,
      });
      setPurchaseResult(data?.data ?? data);
      setShowConfirm(false);
    } catch (err) {
      setError(err?.response?.data?.message ?? 'Error al procesar la compra.');
      setShowConfirm(false);
    } finally { setPurchasing(false); }
  }

  if (loading) return <div className="spinner-page"><div className="spinner"/></div>;
  if (!event) return <div className="page container"><div className="alert alert-error">{error || 'Evento no encontrado.'}</div></div>;

  if (purchaseResult) return (
    <div className="page">
      <div className="container" style={{ maxWidth: 520 }}>
        <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🎉</div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '.5rem' }}>¡Compra exitosa!</h2>
          <p className="text-muted mb-2">Tu compra fue registrada correctamente.</p>
          <div className="summary-box mt-2 mb-2" style={{ textAlign: 'left' }}>
            <div className="summary-row"><span className="text-muted">Evento</span><span style={{ fontWeight: 600 }}>{event.name}</span></div>
            <div className="summary-row"><span className="text-muted">Zona</span><span>{selectedZone?.zoneType}</span></div>
            <div className="summary-row"><span className="text-muted">Boletos</span><span>{quantity}</span></div>
            <div className="summary-row summary-total"><span>Total pagado</span><span className="text-accent">${total.toLocaleString('es-MX')}</span></div>
          </div>
          {purchaseResult?.id && <p className="text-muted" style={{ fontSize: '.8rem' }}>Referencia: #{purchaseResult.id}</p>}
          <button className="btn btn-primary mt-2" onClick={() => navigate('/')}>Volver a Eventos</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="container">
        <button className="btn btn-secondary btn-sm mb-2" onClick={() => navigate('/')}>← Regresar</button>

        {error && <div className="alert alert-error">⚠️ {error}</div>}

        {/* Event header */}
        <div className="card mb-2">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <span className="badge badge-active" style={{ marginBottom: '.5rem' }}>Activo</span>
              <h1 style={{ fontSize: '2rem', fontWeight: 900, letterSpacing: '-.04em', marginBottom: '.3rem' }}>{event.name}</h1>
              <p className="text-muted" style={{ marginBottom: '.5rem' }}>{event.description}</p>
              <div className="d-flex gap-2" style={{ flexWrap: 'wrap' }}>
                <span style={{ fontSize: '.875rem' }}>📅 {formatDate(event.date)}</span>
                <span style={{ fontSize: '.875rem' }}>📍 {event.place}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Zones selection */}
        {zones.length === 0 ? (
          <div className="alert alert-info">Este evento aún no tiene zonas de boletaje configuradas.</div>
        ) : (
          <div className="card mb-2">
            <h3 style={{ fontWeight: 700, marginBottom: '1rem' }}>Selecciona tu zona</h3>
            <div className="zone-cards">
              {zones.map(z => (
                <div key={z.id}
                  className={`zone-card ${selectedZone?.id === z.id ? 'selected' : ''}`}
                  onClick={() => setSelectedZone(z)}
                >
                  <div style={{ fontSize: '1.5rem', marginBottom: '.3rem' }}>{ZONE_ICONS[z.zoneType] ?? '🎫'}</div>
                  <div className="zone-name">{z.zoneType}</div>
                  <div className="zone-price">${Number(z.price).toLocaleString('es-MX')}</div>
                  <div className="zone-available">por boleto</div>
                  {z.capacity != null && <div className="zone-available">Capacidad: {z.capacity}</div>}
                </div>
              ))}
            </div>

            {selectedZone && (
              <>
                <hr className="divider"/>
                <div style={{ maxWidth: 480 }}>
                  <div className="form-row mb-2">
                    <div className="form-group">
                      <label className="form-label">Tu Nombre *</label>
                      <input className="form-control" value={buyerName} onChange={e => setBuyerName(e.target.value)} placeholder="Juan Pérez" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Correo Electrónico *</label>
                      <input className="form-control" type="email" value={buyerEmail} onChange={e => setBuyerEmail(e.target.value)} placeholder="correo@ejemplo.com" />
                    </div>
                  </div>

                  <div className="form-group" style={{ maxWidth: 200 }}>
                    <label className="form-label">Cantidad de Boletos</label>
                    <input className="form-control" type="number" min="1" max="10" value={quantity}
                      onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} />
                  </div>

                  <div className="summary-box mb-2">
                    <div className="summary-row"><span className="text-muted">Zona</span><span>{selectedZone.zoneType}</span></div>
                    <div className="summary-row"><span className="text-muted">Precio unitario</span><span>${Number(selectedZone.price).toLocaleString('es-MX')}</span></div>
                    <div className="summary-row"><span className="text-muted">Cantidad</span><span>× {quantity}</span></div>
                    <div className="summary-row summary-total"><span>Total</span><span className="text-accent">${total.toLocaleString('es-MX')}</span></div>
                  </div>

                  <button
                    className="btn btn-gold btn-full"
                    style={{ padding: '.85rem', fontSize: '1rem' }}
                    disabled={!buyerName || !buyerEmail}
                    onClick={() => setShowConfirm(true)}
                  >
                    Comprar Boletos 🎟
                  </button>
                  {(!buyerName || !buyerEmail) && <p className="text-muted mt-1" style={{ fontSize: '.78rem' }}>Completa tu nombre y correo para continuar.</p>}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Confirm Modal */}
      {showConfirm && (
        <Modal
          title="Confirmar Compra"
          onClose={() => setShowConfirm(false)}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setShowConfirm(false)}>Cancelar</button>
              <button className="btn btn-gold" onClick={handlePurchase} disabled={purchasing}>
                {purchasing ? 'Procesando…' : `Pagar $${total.toLocaleString('es-MX')}`}
              </button>
            </>
          }
        >
          <p className="mb-2">Resumen de tu compra:</p>
          <div className="summary-box">
            <div className="summary-row"><span className="text-muted">Evento</span><strong>{event.name}</strong></div>
            <div className="summary-row"><span className="text-muted">Zona</span><span>{selectedZone?.zoneType}</span></div>
            <div className="summary-row"><span className="text-muted">Comprador</span><span>{buyerName}</span></div>
            <div className="summary-row"><span className="text-muted">Correo</span><span>{buyerEmail}</span></div>
            <div className="summary-row"><span className="text-muted">Boletos</span><span>{quantity}</span></div>
            <div className="summary-row summary-total"><span>Total</span><span className="text-accent">${total.toLocaleString('es-MX')}</span></div>
          </div>
        </Modal>
      )}
    </div>
  );
}
