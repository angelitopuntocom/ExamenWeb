import { useState, useEffect, useCallback } from 'react';
import { getEvents, createEvent, updateEvent, cancelEvent, getZonesByEvent, createZone, updateZone } from '../../api/client';
import Modal from '../../components/Modal';

const EMPTY_EVENT = { name: '', description: '', date: '', place: '', status: 'Active' };
const EMPTY_ZONE  = { zoneType: 'General', price: '', capacity: '' };
const ZONE_TYPES  = ['VIP', 'Preferente', 'General'];

function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function AdminEvents() {
  const [events, setEvents]       = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');
  const [success, setSuccess]     = useState('');

  // Event modal
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEvent, setEditingEvent]     = useState(null);
  const [eventForm, setEventForm]           = useState(EMPTY_EVENT);
  const [saving, setSaving]                 = useState(false);

  // Zone modal
  const [showZoneModal, setShowZoneModal]   = useState(false);
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [selectedEventName, setSelectedEventName] = useState('');
  const [zones, setZones]                   = useState([]);
  const [zoneForm, setZoneForm]             = useState(EMPTY_ZONE);
  const [editingZone, setEditingZone]       = useState(null);
  const [savingZone, setSavingZone]         = useState(false);

  // Cancel confirm
  const [confirmCancel, setConfirmCancel]   = useState(null);

  const loadEvents = useCallback(async () => {
    try {
      setLoading(true);
      const { data } = await getEvents();
      setEvents(Array.isArray(data) ? data : data.data ?? []);
    } catch {
      setError('No se pudieron cargar los eventos. Verifica que la API esté activa.');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  function flash(msg, type = 'success') {
    if (type === 'success') { setSuccess(msg); setTimeout(() => setSuccess(''), 3500); }
    else { setError(msg); setTimeout(() => setError(''), 4000); }
  }

  /* ── Event CRUD ──────────────────────────────────────── */
  function openCreate() {
    setEditingEvent(null);
    setEventForm(EMPTY_EVENT);
    setShowEventModal(true);
  }

  function openEdit(ev) {
    setEditingEvent(ev);
    setEventForm({
      name: ev.name, description: ev.description,
      date: ev.date ? ev.date.substring(0, 16) : '',
      place: ev.place, status: ev.status ?? 'Active',
    });
    setShowEventModal(true);
  }

  async function handleSaveEvent(e) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingEvent) {
        await updateEvent(editingEvent.id, eventForm);
        flash('Evento actualizado correctamente.');
      } else {
        await createEvent(eventForm);
        flash('Evento creado correctamente.');
      }
      setShowEventModal(false);
      loadEvents();
    } catch (err) {
      flash(err?.response?.data?.message ?? 'Error al guardar el evento.', 'error');
    } finally { setSaving(false); }
  }

  async function handleCancelEvent() {
    try {
      await cancelEvent(confirmCancel.id);
      flash('Evento cancelado.');
      setConfirmCancel(null);
      loadEvents();
    } catch {
      flash('Error al cancelar el evento.', 'error');
    }
  }

  /* ── Zone management ─────────────────────────────────── */
  async function openZones(ev) {
    setSelectedEventId(ev.id);
    setSelectedEventName(ev.name);
    setZoneForm(EMPTY_ZONE);
    setEditingZone(null);
    try {
      const { data } = await getZonesByEvent(ev.id);
      setZones(Array.isArray(data) ? data : data.data ?? []);
    } catch { setZones([]); }
    setShowZoneModal(true);
  }

  function openEditZone(z) {
    setEditingZone(z);
    setZoneForm({ zoneType: z.zoneType, price: z.price, capacity: z.capacity ?? '' });
  }

  async function handleSaveZone(e) {
    e.preventDefault();
    setSavingZone(true);
    try {
      if (editingZone) {
        await updateZone(selectedEventId, editingZone.id, zoneForm);
      } else {
        await createZone(selectedEventId, zoneForm);
      }
      const { data } = await getZonesByEvent(selectedEventId);
      setZones(Array.isArray(data) ? data : data.data ?? []);
      setZoneForm(EMPTY_ZONE);
      setEditingZone(null);
      flash(editingZone ? 'Zona actualizada.' : 'Zona agregada.');
    } catch (err) {
      flash(err?.response?.data?.message ?? 'Error al guardar zona.', 'error');
    } finally { setSavingZone(false); }
  }

  const zoneBadge = (t) => ({ VIP: 'badge-vip', Preferente: 'badge-pref', General: 'badge-gen' }[t] ?? 'badge-gen');

  return (
    <div className="page">
      <div className="container">

        {/* Header */}
        <div className="section-header">
          <div>
            <h1 className="section-title">Administración de <span>Eventos</span></h1>
            <p className="section-sub">Crear, editar, cancelar y gestionar zonas de boletaje</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>+ Nuevo Evento</button>
        </div>

        {/* Alerts */}
        {error   && <div className="alert alert-error">⚠️ {error}</div>}
        {success && <div className="alert alert-success">✅ {success}</div>}

        {/* Table */}
        {loading ? (
          <div className="spinner-page"><div className="spinner"/></div>
        ) : events.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🎫</div>
            <div className="empty-title">Sin eventos registrados</div>
            <p>Crea tu primer evento con el botón superior.</p>
          </div>
        ) : (
          <div className="card" style={{ padding: 0 }}>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Evento</th>
                    <th>Fecha</th>
                    <th>Lugar</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {events.map((ev) => (
                    <tr key={ev.id}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{ev.name}</div>
                        <div className="text-muted" style={{ fontSize: '.78rem' }}>{ev.description?.substring(0, 60)}{ev.description?.length > 60 ? '…' : ''}</div>
                      </td>
                      <td style={{ whiteSpace: 'nowrap' }}>{formatDate(ev.date)}</td>
                      <td>{ev.place}</td>
                      <td>
                        <span className={`badge ${ev.status === 'Active' ? 'badge-active' : 'badge-canceled'}`}>
                          {ev.status === 'Active' ? 'Activo' : 'Cancelado'}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          <button className="btn btn-secondary btn-sm" onClick={() => openEdit(ev)}>✏️</button>
                          <button className="btn btn-secondary btn-sm" onClick={() => openZones(ev)} title="Zonas">🎟</button>
                          {ev.status === 'Active' && (
                            <button className="btn btn-danger btn-sm" onClick={() => setConfirmCancel(ev)}>✕</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* ── Event Modal ───────────────────────────────── */}
      {showEventModal && (
        <Modal
          title={editingEvent ? 'Editar Evento' : 'Nuevo Evento'}
          onClose={() => setShowEventModal(false)}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setShowEventModal(false)}>Cancelar</button>
              <button className="btn btn-primary" onClick={handleSaveEvent} disabled={saving}>
                {saving ? 'Guardando…' : editingEvent ? 'Guardar Cambios' : 'Crear Evento'}
              </button>
            </>
          }
        >
          <form onSubmit={handleSaveEvent}>
            <div className="form-group">
              <label className="form-label">Nombre del Evento *</label>
              <input className="form-control" required value={eventForm.name}
                onChange={e => setEventForm({...eventForm, name: e.target.value})}
                placeholder="Ej. Rock en Tu Ciudad 2025" />
            </div>
            <div className="form-group">
              <label className="form-label">Descripción</label>
              <textarea className="form-control" rows={3} value={eventForm.description}
                onChange={e => setEventForm({...eventForm, description: e.target.value})}
                placeholder="Descripción breve del evento..." />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Fecha y Hora *</label>
                <input className="form-control" type="datetime-local" required value={eventForm.date}
                  onChange={e => setEventForm({...eventForm, date: e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Lugar *</label>
                <input className="form-control" required value={eventForm.place}
                  onChange={e => setEventForm({...eventForm, place: e.target.value})}
                  placeholder="Ej. Foro Sol, CDMX" />
              </div>
            </div>
            {editingEvent && (
              <div className="form-group">
                <label className="form-label">Estado</label>
                <select className="form-control" value={eventForm.status}
                  onChange={e => setEventForm({...eventForm, status: e.target.value})}>
                  <option value="Active">Activo</option>
                  <option value="Canceled">Cancelado</option>
                </select>
              </div>
            )}
          </form>
        </Modal>
      )}

      {/* ── Zones Modal ──────────────────────────────── */}
      {showZoneModal && (
        <Modal
          title={`Zonas de Boletaje — ${selectedEventName}`}
          onClose={() => { setShowZoneModal(false); setEditingZone(null); }}
        >
          {/* Zone list */}
          {zones.length > 0 && (
            <div className="mb-2">
              <div className="form-label mb-1">Zonas configuradas</div>
              <div className="card" style={{ padding: 0 }}>
                <table>
                  <thead><tr><th>Zona</th><th>Precio</th><th>Capacidad</th><th></th></tr></thead>
                  <tbody>
                    {zones.map(z => (
                      <tr key={z.id}>
                        <td><span className={`badge ${zoneBadge(z.zoneType)}`}>{z.zoneType}</span></td>
                        <td className="text-accent fw-bold">${Number(z.price).toLocaleString('es-MX')}</td>
                        <td className="text-muted">{z.capacity ?? '—'}</td>
                        <td><button className="btn btn-secondary btn-sm" onClick={() => openEditZone(z)}>✏️</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <hr className="divider"/>
          <div className="form-label mb-1" style={{ color: 'var(--text)' }}>
            {editingZone ? `Editar zona ${editingZone.zoneType}` : 'Agregar zona'}
          </div>
          <form onSubmit={handleSaveZone}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Tipo de Zona *</label>
                <select className="form-control" required value={zoneForm.zoneType}
                  onChange={e => setZoneForm({...zoneForm, zoneType: e.target.value})}>
                  {ZONE_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Precio (MXN) *</label>
                <input className="form-control" type="number" min="0" step="0.01" required
                  value={zoneForm.price}
                  onChange={e => setZoneForm({...zoneForm, price: e.target.value})}
                  placeholder="Ej. 1500" />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Capacidad</label>
              <input className="form-control" type="number" min="1"
                value={zoneForm.capacity}
                onChange={e => setZoneForm({...zoneForm, capacity: e.target.value})}
                placeholder="Número de lugares" />
            </div>
            <div className="d-flex gap-1 justify-end">
              {editingZone && (
                <button type="button" className="btn btn-secondary"
                  onClick={() => { setEditingZone(null); setZoneForm(EMPTY_ZONE); }}>Cancelar</button>
              )}
              <button type="submit" className="btn btn-primary" disabled={savingZone}>
                {savingZone ? 'Guardando…' : editingZone ? 'Actualizar Zona' : 'Agregar Zona'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ── Cancel Confirm Modal ──────────────────── */}
      {confirmCancel && (
        <Modal
          title="¿Cancelar evento?"
          onClose={() => setConfirmCancel(null)}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setConfirmCancel(null)}>No, regresar</button>
              <button className="btn btn-danger" onClick={handleCancelEvent}>Sí, cancelar evento</button>
            </>
          }
        >
          <p>Estás a punto de cancelar <strong>{confirmCancel.name}</strong>. Esta acción no se puede deshacer.</p>
        </Modal>
      )}
    </div>
  );
}
