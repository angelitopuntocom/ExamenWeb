import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import PublicEvents from './pages/public/PublicEvents';
import EventDetail from './pages/public/EventDetail';
import AdminEvents from './pages/admin/AdminEvents';
import './styles/global.css';

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/"           element={<PublicEvents />} />
        <Route path="/events/:id" element={<EventDetail />} />
        <Route path="/admin"      element={<AdminEvents />} />
      </Routes>
    </BrowserRouter>
  );
}
