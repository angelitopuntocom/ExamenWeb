import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const client = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// ── Events ────────────────────────────────────────────────
export const getEvents = () => client.get('/events');
export const getEventById = (id) => client.get(`/events/${id}`);
export const createEvent = (data) => client.post('/events', data);
export const updateEvent = (id, data) => client.put(`/events/${id}`, data);
export const cancelEvent = (id) => client.patch(`/events/${id}/cancel`);

// ── Ticket Zones ─────────────────────────────────────────
export const getZonesByEvent = (eventId) => client.get(`/events/${eventId}/zones`);
export const createZone = (eventId, data) => client.post(`/events/${eventId}/zones`, data);
export const updateZone = (eventId, zoneId, data) => client.put(`/events/${eventId}/zones/${zoneId}`, data);

// ── Purchases ────────────────────────────────────────────
export const purchaseTickets = (data) => client.post('/purchases', data);
export const getPurchasesByEvent = (eventId) => client.get(`/events/${eventId}/purchases`);

export default client;
